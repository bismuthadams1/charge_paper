# cnsdrugs

This script generates a list of FDA-approved drugs and, specifically, central nervous system CNS drugs, with SMILES. For details see [this CureFFI.org blog post](http://www.cureffi.org/2013/10/04/list-of-fda-approved-drugs-and-cns-drugs-with-smiles/).

This code was originally run in Rstudio on a Windows machine in 2013; I haven't updated it since.
